import React from 'react'

export default function Search() {
  return (
    <div className="screen-container">Search</div>
  )
}
