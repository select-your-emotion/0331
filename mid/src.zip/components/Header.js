import React from 'react'
// import './Header.module.css'

function Header() {
  return (
    <header className='container'>
      <h1 className="header-top">SYEmotion</h1>
    </header>
  )
}

export default Header;