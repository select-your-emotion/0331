import React from 'react'

export default function myPlaylist() {
  return (
    <div>myPlaylist</div>
  )
}
